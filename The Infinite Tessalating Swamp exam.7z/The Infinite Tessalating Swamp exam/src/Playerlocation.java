
public class Playerlocation extends Location{
	int a=(int)(Math.random()*10);
	int b=(int)(Math.random()*10);
//	Playerlocation startpoint=new Playerlocation(a,b);
	
	public Playerlocation(int x, int y) {
		setXcoord(x);
		setYcoord(y);
//		System.out.println("location generated");
	}
	public void movement(String compassdirection) {
		if (compassdirection == "north") {
			setYcoord(getYcoord()+1);
		}
		else if(compassdirection=="south"){
			setYcoord(getYcoord()-1);
		}else if(compassdirection=="east") {
			setXcoord(getXcoord()+1);
		}else if(compassdirection=="west") {
			setXcoord(getXcoord()-1);
		}
	}
		
		
	}


