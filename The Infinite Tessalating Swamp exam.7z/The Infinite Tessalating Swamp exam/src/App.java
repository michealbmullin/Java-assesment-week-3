import java.util.Scanner;


public class App {
	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		boolean dead=false;
		int z = 0;
		boolean running=true;
		int a=(int)(Math.random()*10);
		int b=(int)(Math.random()*10);
		System.out.println("initialising game");
		Playerlocation startpoint=new Playerlocation(a,b);
		TreasureLocation winpoint=new TreasureLocation(a,b);
		Encounters encounter= new Encounters();
		Compass compass=new Compass();
		System.out.println("you awake in a dark and mysterious swamp");
		String responce;
		while(running=true) {
			System.out.println("what would you like to do?");
			System.out.println(" 1.move in a compass direction \n 2.check your magical compass \n 3.Dig for treasure \n 4. look around ");
			int i=input.nextInt();
			System.out.println("You have chosen " + i);
			if (i==1) {
				boolean moving = true;
				while(moving=true) {
					System.out.println("what compass direction do you wish to move?, type return to stop moving");
					responce=input.next();
					if (responce.equals("north")) {
						startpoint.movement("north");
					}
					else if (responce.equals("south")) {
						startpoint.movement("south");
					}
					else if (responce.equals("east")) {
						startpoint.movement("east");
					}
					else if (responce.equals("west")) {
						startpoint.movement("west");
					}
					else if ((responce.equals("return"))) {
						moving=false;
						break;
					}
					else{
						System.out.println("please input a valid direction \n \n");
					}
			}
		}
		else if (i==2) {
			System.out.println(compass.checkcompass(startpoint));
		}
		else if(i==3) {
			compass.checkcompass(startpoint);
			
			if((compass.checkcompass(startpoint))==0) {
				System.out.println("congratulations youve found the treasure!");
				running=false;
				break;
			}
			else {
					System.out.println("you find nothing of value \n\n");
			}
		}
		
		else if (i==4) {
			System.out.println("you have a keen look around");
			int random=(int) (Math.random()*10);
			switch (random) {
			case 1:{
				encounter.genEncounter(1);
				startpoint.movement("north");
				startpoint.movement("north");
				startpoint.movement("north");
				System.out.println(" you have to move four tiles north ");
				break;
			}
			case 2:{
				z=(encounter.genEncounter("encounter 2"));
				if (z==1) {
					running=false;
					break;
				}
				else {running=true;
				}
			}
//			case 3:
			default:{
				System.out.println("you see nothing of note, exept endless foggy marshes \n \n");
			}
			break;
			}
		}
		else {
			System.out.println("please input a valid command \n\n");
		}
		if (running=false) {
			System.out.println("thank you for playing");
		}
	
		if (z==1) {
			running=false;
			break;
		}
		continue;	
		}
	}
}
