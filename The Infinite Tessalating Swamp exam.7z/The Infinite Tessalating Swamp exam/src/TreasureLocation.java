
public class TreasureLocation extends Location{
	public TreasureLocation(int x, int y) {
		x=x+(int)(Math.random()*10)+1;
		y=y+(int)(Math.random()*10)+1;
		setXcoord(x);
		setYcoord(y);
}
}
