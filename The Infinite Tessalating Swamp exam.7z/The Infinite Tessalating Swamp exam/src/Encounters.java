import java.util.Scanner;

public class Encounters {
	
	private int encounterid;
	private int lethality;
	public void genEncounter(int no){
		encounterid=no;
		lethality=0;
		System.out.println("you come upon a particulalry boggy patch of marsh, you will have to go around");
		
	}
	public int genEncounter(String string) {
		int z;
		System.out.println("oh no you are sinking into the mud");
		int deathsave=(int) (Math.random()*100);
		lethality=10;
		if (deathsave>lethality) {
			System.out.println(" you strggle against the quicksand ");
			System.out.println("you break free!");
			z=0;
			
		}
		else {
			System.out.println(" you sink into the muck, never to be seen again ");
			z=1;
			
		}
		return z;
	}
	public void genEncounter(boolean bool) {
		System.out.println("you feel a dark and ominous prescence nearby \n what do you do?");
		
	}
}
