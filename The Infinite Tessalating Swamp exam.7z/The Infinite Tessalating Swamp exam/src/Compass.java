
public class Compass extends Location{
	int a=(int)(Math.random()*10);
	int b=(int)(Math.random()*10);
	Playerlocation startpoint=new Playerlocation(a,b);
	TreasureLocation winpoint=new TreasureLocation(a,b);
	
	public float checkcompass(Object startpoint) {
		this.startpoint=(Playerlocation) startpoint;
		a=((Location) startpoint).getXcoord();
		b=((Location) startpoint).getYcoord();
		int c=(winpoint.getXcoord());
		int d=(winpoint.getXcoord());
		int xdiff=a-c;
		int ydiff=b-c;
		double pythag=Math.pow(xdiff,2)+ Math.pow(ydiff, 2);
		double rootpythag=Math.pow(pythag, 0.5);
		return (float) rootpythag;
	}

}
